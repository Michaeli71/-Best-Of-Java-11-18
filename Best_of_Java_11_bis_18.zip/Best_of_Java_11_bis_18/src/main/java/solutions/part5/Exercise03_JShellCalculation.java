package solutions.part5;

import java.util.List;

import jdk.jshell.JShell;
import jdk.jshell.SnippetEvent;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 18" / das Buch "Java – die Neuerungen in Java 17 LTS und 18"
 *
 * @author Michael Inden
 *
 * Copyright 2021/2022 by Michael Inden
 */
public class Exercise03_JShellCalculation {

    public static void main(String args[]) {
        JShell jshell = JShell.create();
        jshell.eval("int x = 7;");
        jshell.eval("int y = 6;");
        List<SnippetEvent> list = jshell.eval("int result = x * y;");
        System.out.println("Size of list: " + list.size());
        System.out.println("Value of the expression is " + list.get(0).value());

        jshell.eval("import java.time.*;");
        jshell.eval("var today = LocalDate.now();");
        // ACHTUNG GANZ WICHTIG!!!
        jshell.eval("import java.util.*;");
        jshell.eval("var values = List.of(1,  2,  3,  4);");

        jshell.variables().forEach(x -> System.out.println("var:" + x.name() + "=" + jshell.varValue(x)));
        List<SnippetEvent> se = jshell.eval("""
                for (var val : values) { 
                     System.out.println("val: " + val);
                }
                """);
        System.out.println("Size of list: " + se.size());
        System.out.println("source: " + se.get(0).snippet().source());
        System.out.println("diagnostics: " + jshell.diagnostics(jshell.snippets().findFirst().get()).toList());
        System.out.println("Value of the expression is : " + se.get(0).value());

        //
        System.out.println("--------------------------------------");
        var valuesSnippet = jshell.variables().filter(varsnippet -> varsnippet.name().contains("values")).findFirst().get();
        var values = jshell.varValue(valuesSnippet);
        System.out.println("values: " + values);
    }
}